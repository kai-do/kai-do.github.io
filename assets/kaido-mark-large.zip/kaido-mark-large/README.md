# Kaido Analytics mark, large

- `kaido-mark-on-<bg>-2048.png`: 2048 x 2048 px, with its background filled in (light #f7faff, dark #0c1b33, teal #0e6b6b).
- `kaido-mark-on-<bg>-2048-transparent.png`: same size, transparent background. The fading arms are blended for the named background, so place each only on that color.
- `kaido-mark-on-<bg>.svg`: vector originals; scale to any size.
